#include <iostream>
using namespace std;

          int main(){
          system("clear");
          int pilih;


          system("chmod 777 logo");
          system("./logo");

          cout << "   1. Repository             6. DNS Server               11. Cloud                   16. Firewall NAT"<<'\n';
          cout << "   2. Update                 7. WEB Server               12. Mail Server             17. LoadBlace"<<'\n';
          cout << "   3. Upgrade                8. MariaDB                  13. DHCP Server             18. VOIP Server"<<'\n';
          cout << "   4. SSH                    9. Install CMS              14. Proxy Server            19. RAPID"<<'\n';
          cout << "   5. FTP Server            10. IP Config                15. NTP Server              00. Keluar "<<'\n';


          cout << ""<<'\n';
          cout << ""<<'\n';

          cout<<"Masukan pilihan anda = ";
          cin>>pilih;
          cout << ""<<'\n';
          cout << ""<<'\n';

                  if (pilih==1) {
                          system("chmod 777 repo/repo.sh");
                          system("chmod 777 repo/repo");
                          system("./repo/repo.sh");

                        }


                else if (pilih==2) {
                  cout<<"SEDANG MELAKUKAN UPDATE PACKAGE REPOSITORY"<<'\n'<<'\n'<<'\n';
                        	system("apt update");
                          system("clear");
                          system("./tools");

                        }

                else if (pilih==3) {
                  cout<<"SEDANG MELAKUKAN UPGRADE PACKAGE DARI REPOSITORY"<<'\n'<<'\n'<<'\n';
                        	system("apt upgrade -y");
                          system("clear");
                          system("./tools");

                        }

                else if (pilih==4) {
                         system("chmod 777 ssh/sshh.sh");
                         system("chmod 777 ssh/sshh");
                         system("./ssh/ssh.sh");
                 }



                else if (pilih==5) {
                        system("clear");
                        system("cd /root/Desktop/tools");
                      	system("chmod 777 ftp/ftp.sh");
                        system("sh ftp/ftp.sh");
                }


                 else if (pilih==6) {
                   system("clear");
                   system("chmod 777 bind/con.sh");
          	       system("./bind/con.sh");

                }

                 else if (pilih==7) {
                   system("clear");
                 	 system("chmod 777 web/web");
                 	 system("./web/web | lolcat");
                }

                else if (pilih==0) {
                }

                else {
                  cout<<"PILIHAN ANDA TIDAK DITEMUKAN..."<<'\n'<<'\n';
                }
          };
