#!/bin/bash
apt install ruby -y
gem install lolcat
chmod 777 tools
.//tools | lolcat
