#include <iostream>
using namespace std;

int main(){
    system("clear");
    system("./logo");

    int pilihan;


    cout<<"     INPUTKAN PILIHAN ANDA "<<'\n';
    cout<<"     1.  Konfig "<<'\n';
    cout<<"     88. Kembali "<<'\n';
    cout<<"     99. Menu Utama "<<'\n';
    cout<<"     00. Keluar "<<'\n'<<'\n'<<'\n';

    cout<<"     INPUTKAN PILIHAN ANDA = ";
    cin>>pilihan;

    if (pilihan==1){
        system("chmod 777 ftp/conf/user1.sh");
        system("./ftp/conf/user1.sh");
        system("./ftp/d6");
    }


    else if(pilihan==88){
        system("/ftp/ftp.sh");
    }

    else if(pilihan==00){
        system("/tools.sh");
    }

    else {
        cout<<"PILIHAN ANDA TIDAK DIKETAHUI";
    }





}