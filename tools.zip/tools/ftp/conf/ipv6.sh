#!/bin/bash


read -p "ON / OFF IPv6 = " port;
echo 'UseIPv6                         '$port >> /etc/proftpd/proftpd.conf