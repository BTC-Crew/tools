#!/bin/bash
clear

read -p "   LOKASI DIRECTORY UNTUK FTP = " lokasi;
echo '<Anonymous '$lokasi'>' >> /etc/proftpd/proftpd.confs
read -p "   INPUTKAN NAMA USER YANG ANDA INGINKAN = " user;
echo '   User                                '$user >> /etc/proftpd/proftpd.conf
echo '</Anonymous>' >> /etc/proftpd/proftpd.conf

read -p "   BUAT USER = " userr;
adduser $userr
