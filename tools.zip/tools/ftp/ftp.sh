#!/bin/bash

chmod 777 ftp/ftpp
./ftp/ftpp | lolcat