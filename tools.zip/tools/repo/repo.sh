#!/bin/bash

chmod 777 repo
./repo/repo | lolcat
