#include <iostream>
using namespace std;
int main()  {

  system("clear");
  int repo;


  system("clear");

                system("./logo");

                  cout<<"Pilih Layanan Repository Anda "<<'\n'<<'\n';
                  cout<<"     1. Data Utama Surabaya"<<'\n';
                  cout<<"     2. Kambing UI"<<'\n';
                  cout<<"     3. Kebo VLSM"<<'\n';
                  cout<<"     4. Mirror UNEJ"<<'\n';
                  cout<<"     5. Custome Repository"<<'\n';
                  cout<<"     88. Menu Utama"<<'\n'<<'\n'<<'\n';

                  cout<<"Masukan pilihan anda = ";
                  cin>>repo;

                  if (repo==1){
                    system("echo 'deb http://kartolo.sby.datautama.net.id/debian/ buster main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kartolo.sby.datautama.net.id/debian/ buster-updates main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kartolo.sby.datautama.net.id/debian-security/ buster/updates main contrib non-free' >> /etc/apt/sources.list");
                    system("./tools.sh");
                  }

                  else if (repo==2){
                    system("echo 'deb http://kambing.ui.ac.id/debian/ buster main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kambing.ui.ac.id/debian/ buster-updates main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kambing.ui.ac.id/debian-security/ buster/updates main contrib non-free' >> /etc/apt/sources.list");
                    system("./tools.sh");
                  }

                  else if (repo==3){
                    system("echo 'deb http://kebo.vlsm.org/debian/ buster main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kebo.vlsm.org/debian/ buster-updates main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://kebo.vlsm.org/debian-security/ buster/updates main contrib non-free' >> /etc/apt/sources.list");
                    system("./tools.sh");
                  }

                  else if (repo==4){
                    system("echo 'deb http://mirror.unej.ac.id/debian/ buster main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://mirror.unej.ac.id/debian/ buster-updates main contrib non-free' >> /etc/apt/sources.list");
                    system("echo 'deb http://mirror.unej.ac.id/debian-security/ buster/updates main contrib non-free' >> /etc/apt/sources.list");
                    system("./tools.sh");
                  }

                  else if (repo==5){
                    system("chmod 777 repo/cusrepo.sh");
                    system("./repo/cusrepo.sh | lolcat");
                    system("./tools.sh");
                   
                  }

                  else if (repo==88) {
                    system("./tools.sh");
                  }

                  else if (repo==00) {
                  }

                  else {
                    cout<<"   PILIHAN ANDA TIDAK DITEMUKAN ";
                  }


                }
