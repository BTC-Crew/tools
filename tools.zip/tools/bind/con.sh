#!/bin/bash
./logo
chmod 777 bind/bindd
./bind/bindd | lolcat
