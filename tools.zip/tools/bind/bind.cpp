#include <iostream>
using namespace std;

int main(){
  int domain;


  cout<<"       INPUTKAN PILIHAN ANDA "<<'\n'<<'\n';
  cout<<"       1. Install BIND9"<<'\n';
  cout<<"       2. File Lokal Zone"<<'\n';
  cout<<"       3. DB.Local"<<'\n';
  cout<<"       4. DB.IP"<<'\n';
  cout<<"       5. RESTART Bind9"<<'\n';
  cout<<"       0. Menu Utama"<<'\n'<<'\n';
  cout<<"       INPUTKAN PILIHAN ANDA = ";
  cin>>domain;

  if (domain==1) {
    system("apt install bind9");
    system("./tools.sh");
  }

  else if (domain==2) {
    system("clear");
    system("chmod 777 bind/bind.sh");
    system("./bind/bind.sh");
  }

  else if (domain==3) {
    system("clear");
    system("chmod 777 bind/fileDomain.sh");
    system("./bind/fileDomain.sh");
  }

  else if (domain==4) {
    system("clear");
    system("chmod 777 bind/fileip.sh");
    system("./bind/fileip.sh");
  }

  else if (domain=5){
    system("clear");
    system("/etc/init.d/bind9 restart");
    system("chmod 777 bind/con.sh");
    system("./bind/con.sh");

  }

}
