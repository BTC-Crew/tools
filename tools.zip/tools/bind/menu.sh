#!/bin/bash

./logo
