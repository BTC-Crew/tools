#!/bin/bash
chmod 777 ssh/sshh
./ssh/sshh | lolcat
