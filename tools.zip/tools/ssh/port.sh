#!/bin/bash

read -p "MASUKAN PORT = " port;
echo "Port $port" >> /etc/ssh/sshd_config
./ssh.sh 
